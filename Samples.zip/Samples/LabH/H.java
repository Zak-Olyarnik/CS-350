package LabH;

public class H {
	public static void main(String[] args) {

		String s1 = "foo";
		String s2 = s1;
		
		String s3 = "bar";
		String s4 = "bar";
		
		String s5 = "FOO";
		String s6 = "Foo";
				
		System.out.println(s1 == s2);
		System.out.println(s3 == s4);
		System.out.println(s5.toLowerCase() == s6.toLowerCase());
	}
}
