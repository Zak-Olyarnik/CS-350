package LabE;

public class E2 extends E1 {

	public void Method()
	{
		System.out.println("E2 Method");
	}
}

