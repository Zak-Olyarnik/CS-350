package LabA;

public class A1 {
	public A1()
	{
		System.out.println("Constructor A1");
	}
}
