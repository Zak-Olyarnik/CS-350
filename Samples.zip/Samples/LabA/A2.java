package LabA;

public class A2 extends A1{
	public A2()
	{
		System.out.println("Constructor A2");
	}

}
