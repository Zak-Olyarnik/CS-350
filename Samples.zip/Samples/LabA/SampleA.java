package LabA;

public class SampleA {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Before A1");
		A1 a1 = new A1();
		System.out.println("Before A2");
		A2 a2 = new A2();
	}

}
