package swap;

public class swap {
	public static void tricky(Point arg1, Point arg2)
	{
	  arg1.x = 100;
	  arg1.y = 100;
	  Point temp = arg1; 
	  arg1 = arg2;
	  arg2 = temp;

	}
	public static void main(String [] args)
	{
	  Point pnt1 = new Point(0,0);
	  Point pnt2 = new Point(0,0);
	  System.out.println("X1: " + pnt1.x + " Y1: " +pnt1.y); 
	  System.out.println("X2: " + pnt2.x + " Y2: " +pnt2.y);
	  System.out.println(" ");
	  tricky(pnt1,pnt2);
	  System.out.println("X1: " + pnt1.x + " Y1:" + pnt1.y); 
	  System.out.println("X2: " + pnt2.x + " Y2: " +pnt2.y);  
	}

}
