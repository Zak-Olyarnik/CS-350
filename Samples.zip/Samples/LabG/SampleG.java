package LabG;

public class SampleG {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		G2 g = new G2();
		
		System.out.println(g.s);
	}


}
