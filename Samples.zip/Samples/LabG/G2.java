package LabG;

public class G2 extends G1{
	private String s = "H2 string";
}
