package LabG;

public class G1 {
	public String s = "H1 string"; 

}
