package LabF;

public class SampleF {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		F f = new F();
		
		System.out.println(f.Method().toString());
	}
}
