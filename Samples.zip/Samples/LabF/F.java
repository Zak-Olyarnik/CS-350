package LabF;

public class F {
	public Boolean Method()
	{
		try
		{
			int i = 5;
			i = i/0;
			return true;
		}
		catch (ArithmeticException e)
		{
			System.out.println("this is catch.");
			return false;
		}
		finally
		{
			System.out.println("this is final.");
			//return true;
		}
	}

	


}
