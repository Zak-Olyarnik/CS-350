package LabEb;

public class SampleEb {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E1 e1 = new E1();
		E2 e1b = new E2();
		
		e1.Method();
		e1b.Method();
	}

}
