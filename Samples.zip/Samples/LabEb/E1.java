package LabEb;

public class E1 {
	public static void Method()
	{
		System.out.println("E1 Method");
	}
}
