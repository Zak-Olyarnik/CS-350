package LabD;

	public interface D2 {

		public void Method();
	}

