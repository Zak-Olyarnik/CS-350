package LabD;

public class SampleD {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//D1 d1 = new D3(); 
		D3 d = new D3();
		
		d.Method();
	}


}
