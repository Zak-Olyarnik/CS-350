package LabD;

public class D3 implements D1,D2 {
	
	public void Method()
	{
		System.out.println("D3 Method");
	}
}
