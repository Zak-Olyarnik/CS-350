package LabD;

public interface D1 {

	public void Method();
}
