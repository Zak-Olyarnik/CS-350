package LabB;

public class B {
	public void Method(String variable)
	{
		variable = "var in method";
	}

}
