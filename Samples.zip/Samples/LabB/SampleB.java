package LabB;

public class SampleB {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		B b = new B();
		String var = "outside B";
		
		System.out.println(var);
		
		b.Method(var);
		System.out.println(var);
	}


}
