package LabI;

public class I {
	public static void main(String[] args) {
		int num = 0;
		
		for (int i = 0; i < 3; ++i)
		{
			//++num;
			//num += num++;
			++num;
		}
		
		System.out.println(num);
	}

}
