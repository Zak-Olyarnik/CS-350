package LabEa;

public class E2 extends E1 {

	public static void Method()
	{
		System.out.println("E2 Method");
	}
}

