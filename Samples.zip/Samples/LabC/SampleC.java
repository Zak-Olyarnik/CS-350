package LabC;

public class SampleC {
	public static void main(String[] args) {
		C3 c = new C3();
		
		c.Method();
	}

}
