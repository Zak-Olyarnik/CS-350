package LabC;

public class C3 extends C2 implements C1 {
	
	public void Method()
	{
		System.out.println("C3 Method");
	}
}
