package LabC;

public class C2 {
	public void Method()
	{
		System.out.println("C2 Method");
	}
}