package LabC;

public interface C1 {

		public void Method();
	}

