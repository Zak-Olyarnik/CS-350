package Lab5;

public interface SizeFactor {
	// only necessary to refer to TeaBased and CoffeeBased subclasses generically in Beverage

	public double cost();
}
