package Lab5;

public class CoffeeBeverage extends Beverage{
	// this class seems unnecessary, but is present on the UML
	
	@Override
	public double cost(){
		return 0.0;
	}
}
