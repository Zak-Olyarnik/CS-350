package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class UI_Driver {
	
	private static ArrayList<Questionnaire> localSurveys = new ArrayList<Questionnaire>();	// container for all Surveys
	private static ArrayList<Questionnaire> localTests = new ArrayList<Questionnaire>();	// container for all Tests
	//private static ArrayList<AnswerSheet> localAnswers = new ArrayList<AnswerSheet>();		// container for all AnswerSheets

	// instantiates the UI_Driver object
	public static void main(String[] args) {
		UI_Driver driver = new UI_Driver();
		driver.mainMenu();			// loads main menu
	}

	// prints main menu to screen and processes user input
	public void mainMenu(){
		String menu = "1  - Create a new Survey\n"
				 	+ "2  - Create a new Test\n"
				 	+ "3  - Display a Survey\n"
				 	+ "4  - Display a Test\n"
				 	+ "5  - Save a Survey\n"
				 	+ "6  - Save a Test\n"
				 	+ "7  - Modify an existing Survey\n"
				 	+ "8  - Modify an existing Test\n"
				 	+ "9  - Load a Survey\n"
				 	+ "10 - Load a Test\n"
				 	+ "11 - Take a Survey\n"
				 	+ "12 - Take a Test\n"
				 	+ "13 - Exit\n";
				 	//+ "13 - Grade a Test - COMING SOON\n"
				 	//+ "14 - Tabulate a Survey - COMING SOON\n"
				 	//+ "15 - Tabulate a Test - COMING SOON\n"
		System.out.println(menu);
		Scanner s = new Scanner(System.in);
		String choice = s.nextLine();		// reads in choice
		while (! choice.equals("13")){		// loops to take in new commands
			switch (choice){
			case "1":	// create Survey
				Questionnaire q = new Questionnaire();
				q.create(s, false);			// differentiates as Survey
				addMenu(s, q);				// adds Questions
				localSurveys.add(q);		// adds to list of Surveys
				q.save();					// auto-saves
				break;
			case "2":	// create Test
				q = new Questionnaire();
				q.create(s, true);			// differentiates as Test
				addMenu(s, q);				// adds Questions and creates AnswerSheet
				localTests.add(q);			// adds to list of Tests
				q.save();					// auto-saves
				break;
			case "3":	// display Survey
				if (localSurveys.size() == 0){		// Surveys must be loaded locally before doing anything else with them
					System.out.println("No Surveys loaded locally\n");
				}else{
					System.out.println("Which Survey would you like to display?");
					int i = 1;
					for(Questionnaire survey : localSurveys){
						System.out.println(i + " - " + survey.getTitle());		// prints the list of localSurveys
						i++;
					}
					q = localSurveys.get(inputCheck(s, i-1, "Survey", "display") - 1);	// error checking
					q.display();		// displays the chosen Survey
				}
				break;
			case "4":	// display Test
				if (localTests.size() == 0){		// Tests must be loaded locally before doing anything else with them
					System.out.println("No Tests loaded locally\n");
				}else{
					System.out.println("Which Test would you like to display?");
					int i = 1;
					for(Questionnaire test : localTests){
						System.out.println(i + " - " + test.getTitle());		// prints the list of localTests
						i++;
					}
					q = localTests.get(inputCheck(s, i-1, "Test", "display") - 1);	// error checking
					q.display();						// displays the chosen Test
					AnswerSheet a = new AnswerSheet();
					a.setName("Key");
					a = a.load(q);						// loads the AnswerSheet key corresponding with the chosen Test
					a.display();						// displays the AnswerSheet
				}
				break;
			case "5":	// save Survey from the list of localSurveys
				if (localSurveys.size() == 0){
					System.out.println("No modified Surveys to save\n");
				}else{
					System.out.println("Which Survey would you like to save?");
					int i = 1;
					for(Questionnaire survey : localSurveys){
						System.out.println(i + " - " + survey.getTitle());		// prints the list of localSurveys
						i++;
					}
					q = localSurveys.get(inputCheck(s, i-1, "Survey", "save") - 1);	// error checking
					q.save();				// saves the chosen Survey
				}
				break;
			case "6":	// save Test from the list of localTests
				if (localTests.size() == 0){
					System.out.println("No modified Tests to save\n");
				}else{
					System.out.println("Which Test would you like to save?");
					int i = 1;
					for(Questionnaire test : localTests){
						System.out.println(i + " - " + test.getTitle());		// prints the list of localTests
						i++;
					}
					q = localTests.get(inputCheck(s, i-1, "Test", "save") - 1);		// error checking
					q.save();				// saves the chosen Test
				}
				break;
			case "7":	// modify Survey
				if (localSurveys.size() == 0){		// Surveys must be loaded locally before doing anything else with them
					System.out.println("No Surveys loaded locally\n");
				}else{
					System.out.println("Which Survey would you like to modify?");
					int i = 1;
					for(Questionnaire survey : localSurveys){
						System.out.println(i + " - " + survey.getTitle());		// prints the list of localSurveys
						i++;
					}
					q = localSurveys.get(inputCheck(s, i-1, "Survey", "modify") - 1);	// error checking
					do{
						int modQuest = q.modify(s);			// asks which Question to modify
						q.getQuestion(modQuest).modify(s);	// modifies that Question
						q.getQuestion(modQuest).display();	// displays the modified Question for confirmation 
						System.out.println("Modify another question? (y/n)");
					} while(s.nextLine().equals("y"));		// loops to allow more modification
					q.save();
				}
				break;
			case "8":	// modify Test
				if (localTests.size() == 0){		// Tests must be loaded locally before doing anything else with them
					System.out.println("No Tests loaded locally\n");
				}else{
					System.out.println("Which Test would you like to modify?");
					int i = 1;
					for(Questionnaire test : localTests){
						System.out.println(i + " - " + test.getTitle());		// prints the list of localTests
						i++;
					}
					q = localTests.get(inputCheck(s, i-1, "Test", "modify") - 1);		// error checking
					AnswerSheet a = new AnswerSheet();
					a.setName("Key");
					a = a.load(q);				// loads the AnswerSheet key corresponding with the chosen Test
					do{
						int modQuest = q.modify(s);			// asks which Question to modify
						q.getQuestion(modQuest).modify(s);	// modifies that Question
						q.getQuestion(modQuest).display();	// displays the modified Question for confirmation
						a.getAnswer(modQuest).linkQuestion(q.getQuestion(modQuest));	// links the modified Question to its Answer
						a.getAnswer(modQuest).modify(s);	// modifies that Answer in case the Question changed
						q.getQuestion(modQuest).display();	// displays the modified Question and Answer for confirmation
						a.getAnswer(modQuest).display();
						System.out.println("Modify another question? (y/n)");
					} while(s.nextLine().equals("y"));		// loops to allow more modification
					a.save();		// auto-saves
					q.save();
				}
				break;
			case "9":	// load Survey from file
				q = new Questionnaire();
				q = q.load(s, false);
				if (q != null){
					localSurveys.add(q);
					System.out.println(q.getTitle() + " loaded locally\n");
				}
				break;
			case "10":	// load Test from file
				q = new Questionnaire();
				q = q.load(s, true);
				if (q != null){
					localTests.add(q);
					//AnswerSheet a = new AnswerSheet();
					//a = a.load(q);
					//localAnswers.add(a);
					System.out.println(q.getTitle() + " loaded locally\n");
				}
				break;
			case "11":	// take survey
				if (localSurveys.size() == 0){		// Surveys must be loaded locally before doing anything else with them
					System.out.println("No Surveys loaded locally\n");
				}else{
					System.out.println("Which Survey would you like to take?");
					int i = 1;
					for(Questionnaire survey : localSurveys){
						System.out.println(i + " - " + survey.getTitle());		// prints the list of localSurveys
						i++;
					}
					q = localSurveys.get(inputCheck(s, i-1, "Survey", "take") - 1);		// error checking
					AnswerSheet a = new AnswerSheet();
					a.linkQuestionnaire(q);
					a.takeQuestionnaire(s);
					a.setName(Integer.toString(q.getNumResponses()));	// names Survey AnswerSheet anonymously based on number of times Survey has been
					a.save();												// filled out
					q.save();
					System.out.println();
				}
				break;
			case "12":	// take test
				if (localTests.size() == 0){		// Tests must be loaded locally before doing anything else with them
					System.out.println("No Tests loaded locally\n");
				}else{
					System.out.println("Which Test would you like to take?");
					int i = 1;
					for(Questionnaire test : localTests){
						System.out.println(i + " - " + test.getTitle());		// prints the list of localTests
						i++;
					}
					q = localTests.get(inputCheck(s, i-1, "Test", "take") - 1);		// error checking
					AnswerSheet a = new AnswerSheet();
					System.out.println("Enter your name:");
					a.setName(s.nextLine());				// names Test AnswerSheet based on student name
					a.linkQuestionnaire(q);
					a.takeQuestionnaire(s);
					a.save();
					q.save();
					System.out.println();
				}
				break;
			/*case "13":	// grade test
				break;
			case "14":	// tabulate survey
				break;
			case "15":	// tabulate test
				break;*/
			default:	// bad input
				System.out.println("Please enter the number of your choice.\n");
				break;
			}
			System.out.println(menu);	// resets menu
			choice = s.nextLine();
		}
		s.close();			// closes Scanner and quits
		System.exit(0);
	}
	
	// adds Questions.  If more question types are added, changes should be localized here
	public void addMenu(Scanner s, Questionnaire q){
		String addMenu = "\n1 - Add a new True or False Question\n"
						 + "2 - Add a new Multiple Choice Question\n"
						 + "3 - Add a new Short Answer Question\n"
						 + "4 - Add a new Essay Question\n"
						 + "5 - Add a new Matching Question\n"
						 + "6 - Add a new Ranking Question\n"
						 + "7 - Finish and Save\n";
		AnswerSheet key = new AnswerSheet();		// AnswerSheets for Tests are created at the same time as Test
		System.out.println(addMenu);
		String choice = s.nextLine();
		while (! choice.equals("7")){	// loops to take in new commands
			Question newQ = null;
			switch (choice){
			case "1":	// true or false
				newQ = new TrueFalse();
				break;
			case "2":	// multiple choice
				newQ = new MultChoice();
				break;
			case "3":	// short answer
				Write sa = new Write();
				sa.setLength(30);			// difference between short answer and essay is character limit
				newQ = sa;
				break;
			case "4":	// essay
				Write es = new Write();
				es.setLength(1500);
				newQ = es;
				break;
			case "5":	// matching
				newQ = new Matching();
				break;
			case "6":	// ranking
				newQ = new Ranking();
				break;
			default:	// bad input
				System.out.println("Please enter the number of your choice.");
				break;
			}
			newQ.create(s);				// actually creates the Question
			newQ.display();
			q.addQuestion(newQ);		// adds Question to Questionnaire
			if (q.getGradeable()){		// adds Answers if Questionnaire is a Test
				if (newQ instanceof Write && ((Write) newQ).getLength() == 1500){	// essay Questions do not have correct Answers so they must be handled
						WriteAnswer wa = new WriteAnswer();								// specially.  I know this is bad, but I don't want to modify the 
						wa.linkQuestion(newQ);											// Write class because the normal selectAnswer() is still needed for 
						wa.setAns("ESSAY");												// students taking the Questionnaire
						key.addAnswer(wa);
				}else{
					System.out.println("Enter correct answer:");
					Answer newA = newQ.selectAnswer(s);				// overridden method creates the Answer of the correct subclass matching the Question
					key.addAnswer(newA);							// adds the Answer to the AnswerSheet
				}
			}
			System.out.println(addMenu);	// resets menu
			choice = s.nextLine();
		}
		if (q.getGradeable()){		// if it's a Test, do cleanup with the AnswerSheet
			key.setName("Key");			// designates the AnswerSheet as a Key
			key.linkQuestionnaire(q);	// links AnswerSheet to Test
			key.save();					// saves AnswerSheet
			//localAnswers.add(key);
		}
	}
	
	// ensures good input
	public int inputCheck(Scanner s, int bound, String item, String action){
		int input;
		do{		// error checking - integer > 0 and < total number of Questionnaires available
			while (!s.hasNextInt()){
			System.out.println("Which " + item + " would you like to " + action + "?");
			s.next();
			}
			input = s.nextInt();
			if(input < 1 || input > bound){
				System.out.println("Which " + item + " would you like to " + action + "?");
			}
		} while (input < 1 || input > bound);
		s.nextLine();		// clears scanner
		return input;
	}
}
