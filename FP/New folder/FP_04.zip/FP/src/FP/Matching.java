package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class Matching extends Question{

	private int numChoices;												// number of choices
	private ArrayList<String> leftColumn = new ArrayList<String>();		// left column choices
	private ArrayList<String> rightColumn = new ArrayList<String>();	// right column choices
	
	@Override
	public void create(Scanner s){
		System.out.println("Enter a prompt for your matching question:");
		setPrompt(s.nextLine());
		System.out.println("Enter the number of choices per column:");
		int input;
		do{		// error checking - integer > 0
			while (!s.hasNextInt()){
				System.out.println("Enter the number of choices per column:");
				s.next();
			}
			input = s.nextInt();
			if(input < 1){
			System.out.println("Enter the number of choices per column:");
			}
		} while (input < 1);
		s.nextLine();		// clears scanner
		setNumChoices(input);
		// asks for choices
		for (int i=0; i<input; i++){
			System.out.println("Enter left column choice #" + (i+1) + ":");
			addLeft(s.nextLine());
		}
		for (int i=0; i<input; i++){
			System.out.println("Enter right column choice #" + (i+1) + ":");
			addRight(s.nextLine());
		}
	}
	
	@Override
	public void display(){
		System.out.println(getPrompt());
		char alphabet = 'A';
		for (int i=0; i<numChoices; i++){
			System.out.println(leftColumn.get(i) + "				" + alphabet + ") " + rightColumn.get(i));		// concatenates the choices with letters
			alphabet++;	
		}
	}
	
	@Override
	public void modify(Scanner s){
		display();
		// modify prompt
		System.out.println("Would you like to modify the prompt? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			System.out.println("Enter a new prompt:");
			setPrompt(s.nextLine());
		}
		// modify number of choices
		System.out.println("Would you like to modify the number of choices? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			System.out.println("Enter the number of choices:");
			int input;
			do{		// error checking - integer > 0
				while (!s.hasNextInt()){
					System.out.println("Enter the number of choices:");
					s.next();
				}
				input = s.nextInt();
				if(input < 1){
				System.out.println("Enter the number of choices:");
				}
			} while (input < 1);
			s.nextLine();		// clears scanner
			while (input < getNumChoices()){	// deletes choices if new number < current number.  Choices are deleted from both columns to maintain matching
				System.out.println("Enter letter of left column choice to delete:");
				listChoices("left");
				int pos;
				do{		// error checking - letter in range
					pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;		// shift from 'A' to '0' is 10
					if(pos < 0 || pos > getNumChoices()-1){
						System.out.println("Enter letter of left column choice to delete:");
					}
				} while (pos < 0 || pos > getNumChoices()-1);
				leftDeleteChoice(pos);				// deletes choice
				System.out.println("Enter letter of right column choice to delete:");
				listChoices("right");
				do{		// error checking - letter in range
					pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;		// shift from 'A' to '0' is 10
					if(pos < 0 || pos > getNumChoices()-1){		// must re-print prompt
						System.out.println("Enter letter of right column choice to delete:");
					}
				} while (pos < 0 || pos > getNumChoices()-1);
				rightDeleteChoice(pos);					// deletes choice
				setNumChoices(getNumChoices() - 1);		// decrements total number of choices
			}
			while(input > getNumChoices()){		// adds choices if new number > current number.  Choices are added to both columns to maintain matching
				System.out.println("Enter new left column choice #" + (getNumChoices() + 1) + ":");
				addLeft(s.nextLine());					// adds choice
				System.out.println("Enter new right column choice #" + (getNumChoices() + 1) + ":");
				addRight(s.nextLine());					// adds choice
				setNumChoices(getNumChoices() + 1);		// increments total number of choices
			}
		}
		// modify text of left column choices
		System.out.println("Would you like to modify any left column choices? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			do{
				System.out.println("Which choice would you like to modify?");
				listChoices("left");
				int pos;
				do{		// error checking - letter in range
					pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;		// shift from 'A' to '0' is 10
					if(pos < 0 || pos > getNumChoices()-1){
						System.out.println("Which choice would you like to modify?");
					}
				} while (pos < 0 || pos > getNumChoices()-1);
				System.out.println("Enter new choice:");
				leftColumn.set(pos, s.nextLine());
				System.out.println("Would you like to modify any left column choices? (y/n)");
			}while(s.nextLine().toUpperCase().equals("Y"));
		}
		// modify text of right column choices
		System.out.println("Would you like to modify any right column choices? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			do{
				System.out.println("Which choice would you like to modify?");
				listChoices("right");
				int pos;
				do{		// error checking - letter in range
					pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;		// shift from 'A' to '0' is 10
					if(pos < 0 || pos > getNumChoices()-1){
						System.out.println("Which choice would you like to modify?");
					}
				} while (pos < 0 || pos > getNumChoices()-1);
				System.out.println("Enter new choice:");
				rightColumn.set(pos, s.nextLine());
				System.out.println("Would you like to modify any right column choices? (y/n)");
			}while(s.nextLine().toUpperCase().equals("Y"));
		}
	}
	
	@Override
	public MatchingAnswer selectAnswer(Scanner s){
		MatchingAnswer ma = new MatchingAnswer();		// instantiates a new Answer
		ma.linkQuestion(this);							// links to this Question
		ma.choose(s);									// selects and stores Answer
		return ma;
	}
	
	// prints all choices to screen, concatenated with letters
	public void listChoices(String col){
		char alphabet = 'A';
		for (int i=0; i<numChoices; i++){
			if (col.equals("left")){
				System.out.print(alphabet + ") " + leftColumn.get(i) + "   ");
			}else if (col.equals("right")){
				System.out.print(alphabet + ") " + rightColumn.get(i) + "   ");
			}
			alphabet++;	
		}
		System.out.println();
	}
	
	// adds a choice to the left column
	public void addLeft(String s){
		leftColumn.add(s);
	}
	
	// adds a choice to the right column
	public void addRight(String s){
		rightColumn.add(s);
	}
	
	// deletes the choice at position i of left column
	public void leftDeleteChoice(int i){
		leftColumn.remove(i);
	}
	
	// deletes the choice at position i of right column
	public void rightDeleteChoice(int i){
		rightColumn.remove(i);
	}
	
	// sets the number of choices
	public void setNumChoices(int i){
		numChoices = i;
	}
	
	// returns the number of choices
	public int getNumChoices(){
		return numChoices;
	}
	
	// returns the choice at position i of left column
	public String getLeft(int i){
		return leftColumn.get(i);
	}
}
