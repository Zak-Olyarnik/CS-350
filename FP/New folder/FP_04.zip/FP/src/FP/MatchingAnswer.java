package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class MatchingAnswer extends Answer {

	private Matching que;												// linked Question
	private ArrayList<Character> ansList = new ArrayList<Character>();	// list of Answer letters ordered according to first column
	
	@Override
	public void choose(Scanner s){		// answer Matching by entering letter choices in order of first column matches
		ansList.clear();
		for (int i=0; i<getQuestion().getNumChoices(); i++){		// asks for Answers corresponding to the first column, in order
			System.out.println("Enter letter matching choice " + getQuestion().getLeft(i) + ":");
			String choice;		// entered letter
			int numChoice;		// entered letter converted to number for error checking
			do{			// error checking - letter in range
				choice = s.nextLine().toUpperCase();
				numChoice = Character.getNumericValue(choice.charAt(0)) - 10;		// shift from 'A' to '0' is 10
				if(numChoice < 0 || numChoice > getQuestion().getNumChoices()-1){
					System.out.println("Enter letter matching choice " + getQuestion().getLeft(i) + ":");
				}
			} while (numChoice < 0 || numChoice > getQuestion().getNumChoices()-1);
			add(choice.charAt(0));		// stores Answer
		}
	}
	
	@Override
	public void display(){
		for (int i=0; i<ansList.size(); i++){
			System.out.println(ansList.get(i));
		}
	}
	
	@Override
	public void linkQuestion(Question q){
		que = (Matching) q;
	}
	
	@Override
	public Matching getQuestion(){
		return que;
	}
	
	// stores Answer
	public void add(char i){
		ansList.add(i);
	}
}
