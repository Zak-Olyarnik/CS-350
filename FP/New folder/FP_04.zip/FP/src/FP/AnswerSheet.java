package FP;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class AnswerSheet implements Serializable{

	private ArrayList<Answer> answersList = new ArrayList<Answer>();		// actual list of all answers
	private Questionnaire quest;											// linked Questionnaire
	private String name;													// student's name, Survey iterator, or "Key"
	
	// prints Answersheet to screen
	public void display(){
		System.out.println("Answers:");
		for(int i=0; i<answersList.size(); i++){	// prints all Answers, enumerated
			System.out.print(i+1 + ") " );
			answersList.get(i).display();
			System.out.println();
		}
	}

	// serializes to file.  All AnswerSheets saved in Answer folder with .Answer extension
	public void save(){
		try
	      {
			new File("Answer").mkdir();		// creates Answer directory if does not exist
	        FileOutputStream outfile = new FileOutputStream("Answer\\" + getQuestionnaire().getTitle() + "." + getName() + ".Answer");
	        ObjectOutputStream out = new ObjectOutputStream(outfile);
	        out.writeObject(this);
	        out.close();
	        outfile.close();
	        System.out.println(getQuestionnaire().getTitle() + " answers saved successfully");
	      }catch(IOException i){
	          i.printStackTrace();
	      }
	}
	
	// deserializes AnswerSheet from file
	public AnswerSheet load(Questionnaire q){
		AnswerSheet loaded = null;
		String filename = "Answer\\" + q.getTitle() + "." + getName() + ".Answer";	// AnswerSheet named based on Test and student name or Survey iterator
		try
		{
			FileInputStream infile = new FileInputStream(filename);
			ObjectInputStream in = new ObjectInputStream(infile);
			loaded = (AnswerSheet) in.readObject();
			in.close();
			infile.close();
		}catch(IOException e){
			e.printStackTrace();
			return loaded;
		}catch(ClassNotFoundException c){
			System.out.println("Class not found");
			c.printStackTrace();
			return loaded;
		}
		loaded.linkQuestionnaire(q);	// links AnswerSheet to Questionnaire
		return loaded;
	}
	
	// answers the Questions on a Questionnaire
	public void takeQuestionnaire(Scanner s){
		for (int i=0; i<getQuestionnaire().getSize(); i++){
			System.out.print(i+1 + ") " );
			getQuestionnaire().getQuestion(i).display();
			Answer newA = getQuestionnaire().getQuestion(i).selectAnswer(s);
			this.addAnswer(newA);
			System.out.println();
		}
		getQuestionnaire().addResponse();	// indicates that an AnswerSheet has been filled out
	}
	
	// adds Answer to list
	public void addAnswer(Answer a){
		answersList.add(a);
	}
	
	// links AnswerSheet and Questionnaire
	public void linkQuestionnaire(Questionnaire q){
		quest = q;
	}
	
	// returns linked Questionnaire
	public Questionnaire getQuestionnaire(){
		return quest;
	}
	
	// returns Answer at position i
	public Answer getAnswer(int i){
		return answersList.get(i);
	}
	
	// returns number of Answers
	public int getSize(){
		return answersList.size();
	}
	
	// sets student's name, Survey iterator, or "Key"
	public void setName(String s){
		name = s;
	}
	
	// returns name
	public String getName(){
		return name;
	}
}
