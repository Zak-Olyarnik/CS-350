package FP;

import java.util.Scanner;

public class Write extends Question{

	private int maxLength;	// differentiates short answer (=30) and essay (=1500)
	
	@Override
	public void create(Scanner s){
		String essayOrShort;
		if(getLength() == 30){
			essayOrShort = "short answer";
		}else{
			essayOrShort = "essay";
		}
		System.out.println("Enter a prompt for your " + essayOrShort + " question:");
		setPrompt(s.nextLine());		// stores prompt
	}
	
	@Override
	public void display(){
		System.out.println(getPrompt());
	}
	
	@Override
	public void modify(Scanner s){
		display();
		// modify prompt
		System.out.println("Would you like to modify the prompt? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			System.out.println("Enter a new prompt:");
			setPrompt(s.nextLine());
		}
	}
	
	@Override
	public WriteAnswer selectAnswer(Scanner s){
		WriteAnswer wa = new WriteAnswer();		// instantiates a new Answer
		wa.linkQuestion(this);					// links to this Question
		wa.choose(s);							// selects and stores Answer
		return wa;
	}
	
	// sets maximum answer field length
	public void setLength(int i){
		maxLength = i;
	}
	
	// returns maximum answer field length
	public int getLength(){
		return maxLength;
	}
}
