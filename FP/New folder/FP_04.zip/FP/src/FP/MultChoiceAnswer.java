package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class MultChoiceAnswer extends Answer {
	
	private MultChoice que;													// linked Question
	private ArrayList<Character> ansList = new  ArrayList<Character>();		// list of Answer letters (one or more)
	
	@Override
	public void choose(Scanner s){		// answer MultChoice by entering letter of correct Answer (possibly multiple)
		ansList.clear();
		String choice;		// entered letter
		int numChoice;		// entered letter converted to number for error checking
		do{		// error checking - letter in range
			choice = s.nextLine().toUpperCase();
			numChoice = Character.getNumericValue(choice.charAt(0)) - 10;		// shift from 'A' to '0' is 10
			if(numChoice < 0 || numChoice > getQuestion().getNumChoices()-1){
				System.out.println("Enter answer:");
			}
		} while (numChoice < 0 || numChoice > getQuestion().getNumChoices()-1);
		add(choice.charAt(0));
		if (getQuestion().getNumSelectableChoices() > 1){		// ask for additional Answers if Question supports them
			for (int i=1; i<getQuestion().getNumSelectableChoices(); i++){
				System.out.println("Question accepts multiple answers...Enter another choice:");
				do{		// error checking - letter in range
					choice = s.nextLine().toUpperCase();
					numChoice = Character.getNumericValue(choice.charAt(0)) - 10;		// shift from 'A' to '0' is 10
					if(numChoice < 0 || numChoice > getQuestion().getNumChoices()-1){
						System.out.println("Enter answer:");
					}
				} while (numChoice < 0 || numChoice > getQuestion().getNumChoices()-1);
				add(choice.charAt(0));	// stores Answer
			}
		}
	}
	
	@Override
	public void display(){
		for (int i=0; i<ansList.size(); i++){
			System.out.println(ansList.get(i));
		}
	}
	
	@Override
	public void linkQuestion(Question q){
		que = (MultChoice) q;
	}
	
	@Override
	public MultChoice getQuestion(){
		return que;
	}
	
	// stores Answer
	public void add(char s){
		ansList.add(s);
	}
}
