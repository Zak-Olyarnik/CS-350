package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class TrueFalse extends Question{
	private ArrayList<String> choices = new ArrayList<String>();	// list of choices
	
	@Override
	public void create(Scanner s){
		System.out.println("Enter a prompt for your true or false question:");
		setPrompt(s.nextLine());
		addChoice("A) True");
		addChoice("B) False");
	}
	
	@Override
	public void display(){
		System.out.println(getPrompt());
		for (int i=0; i<2; i++){			// T/F will always only have 2 choices
			System.out.print(choices.get(i) + "   ");
		}
		System.out.println();
	}
	
	@Override
	public void modify(Scanner s){
		display();
		// modify prompt
		System.out.println("Would you like to modify the prompt? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			System.out.println("Enter a new prompt:");
			setPrompt(s.nextLine());
		}
	}
	
	@Override
	public TrueFalseAnswer selectAnswer(Scanner s){
		TrueFalseAnswer tfa = new TrueFalseAnswer();	// instantiates a new Answer
		tfa.linkQuestion(this);							// links to this Question
		tfa.choose(s);									// selects and stores Answer
		return tfa;
	}
	
	// adds possible choices to list
	public void addChoice(String s){
		choices.add(s);
	}
}
