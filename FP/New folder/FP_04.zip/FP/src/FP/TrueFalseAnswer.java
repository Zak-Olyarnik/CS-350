package FP;

import java.util.Scanner;

public class TrueFalseAnswer extends Answer {

	private TrueFalse que;		// linked Question
	private char ans;			// Answer letter
	
	@Override
	public void choose(Scanner s){		// answer T/F by entering letter of correct Answer or whole Answer
		String choice;
		do{		// error checking - first character is either "A" or "B"
			choice = s.nextLine().toUpperCase();
			if (!(choice.charAt(0) == 'A' || choice.charAt(0) == 'B')){
				System.out.println("Enter answer:");
			}
		}while(!(choice.charAt(0) == 'A' || choice.charAt(0) == 'B'));
		setAns(choice.charAt(0));	// stores Answer
	}
	
	@Override
	public void display(){
		System.out.println(ans);
	}
	
	@Override
	public void linkQuestion(Question q){
		que = (TrueFalse) q;
	}
	
	@Override
	public TrueFalse getQuestion(){
		return que;
	}
	
	// stores Answer
	public void setAns(char c){
		ans = c;
	}
}
