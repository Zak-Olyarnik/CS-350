package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class MultChoice extends Question{

	private int numChoices;											// number of choices
	private int numSelectableChoices;								// number of selectable choices
	private ArrayList<String> choices = new ArrayList<String>();	// list of choices
	
	@Override
	public void create(Scanner s){
		System.out.println("Enter a prompt for your multiple choice question:");
		setPrompt(s.nextLine());
		System.out.println("Enter the number of choices for your multiple choice question:");
		int input;
		do{		// error checking - integer > 0
			while (!s.hasNextInt()){
				System.out.println("Enter the number of choices for your multiple choice question:");
				s.next();
			}
			input = s.nextInt();
			if(input < 1){
			System.out.println("Enter the number of choices for your multiple choice question:");
			}
		} while (input < 1);
		s.nextLine();		// clears scanner
		setNumChoices(input);
		for (int i=0; i<input; i++){
			System.out.println("Enter answer choice #" + (i+1) + ":");
			addChoice(s.nextLine());
		}
		System.out.println("Enter the number of selectable choices for your multiple choice question:");
		do{		// error checking - integer > 0 and <= total number of choices
			while (!s.hasNextInt()){
				System.out.println("Enter the number of selectable choices for your multiple choice question:");
				s.next();
			}
			input = s.nextInt();
			if(input < 1){
				System.out.println("Enter the number of selectable choices for your multiple choice question:");
			}else if (input > getNumChoices()){
				System.out.println("Selectable choices must not be greater than total choices.  Enter the number of selectable choices for your multiple choice question:");
			}
		} while (input < 1 || input > getNumChoices());
		s.nextLine();		// clears scanner
		setNumSelectableChoices(input);
	}
	
	@Override
	public void display(){
		System.out.println(getPrompt());
		listChoices();
	}
	
	public void modify(Scanner s){
		display();
		// modify prompt
		System.out.println("Would you like to modify the prompt? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			System.out.println("Enter a new prompt:");
			setPrompt(s.nextLine());
		}
		// modify number of choices
		System.out.println("Would you like to modify the number of choices? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			System.out.println("Enter the number of choices:");
			int input;
			do{		// error checking - integer > 0
				while (!s.hasNextInt()){
					System.out.println("Enter the number of choices:");
					s.next();
				}
				input = s.nextInt();
				if(input < 1){
				System.out.println("Enter the number of choices:");
				}
			} while (input < 1);
			s.nextLine();		// clears scanner
			while (input < getNumChoices()){		// deletes choices if new number < current number
				System.out.println("Enter letter of choice to delete:");
				listChoices();
				int pos;
				do{		// error checking - letter in range
					pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;		// shift from 'A' to '0' is 10
					if(pos < 0 || pos > getNumChoices()-1){
						System.out.println("Enter letter of choice to delete:");
					}
				} while (pos < 0 || pos > getNumChoices()-1);
				deleteChoice(pos);						// deletes choice
				setNumChoices(getNumChoices() - 1);		// decrements total number of choices
			}
			while(input > getNumChoices()){			// adds choices if new number > current number
				System.out.println("Enter new answer choice #" + (getNumChoices() + 1) + ":");
				addChoice(s.nextLine());				// adds choice
				setNumChoices(getNumChoices() + 1);		// increments total number of choices
			}
		}
		// modify text of choices
		System.out.println("Would you like to modify any of the choices? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			do{
				System.out.println("Which choice would you like to modify?");
				listChoices();				
				int pos;
				do{		// error checking - letter in range
					pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;		// shift from 'A' to '0' is 10
					if(pos < 0 || pos > getNumChoices()-1){
						System.out.println("Which choice would you like to modify?");
					}
				} while (pos < 0 || pos > getNumChoices()-1);
				System.out.println("Enter new choice:");
				choices.set(pos, s.nextLine());
				System.out.println("Would you like to modify any of the choices? (y/n)");
			}while(s.nextLine().toUpperCase().equals("Y"));
		}
		// modify number of selectable choices
		System.out.println("Would you like to modify the number of selectable choices? (y/n)");
		if(s.nextLine().toUpperCase().equals("Y")){
			int input;
			System.out.println("Enter the number of selectable choices for your multiple choice question:");
			do{		// error checking - integer > 0 and <= total number of choices
				while (!s.hasNextInt()){
					System.out.println("Enter the number of selectable choices for your multiple choice question:");
					s.next();
				}
				input = s.nextInt();
				if(input < 1){
					System.out.println("Enter the number of selectable choices for your multiple choice question:");
				}else if (input > getNumChoices()){
					System.out.println("Selectable choices must not be greater than total choices.  Enter the number of selectable choices for your multiple choice question:");
				}
			} while (input < 1 || input > getNumChoices());
			s.nextLine();		// clears scanner
			setNumSelectableChoices(input);
		}
	}
	
	@Override
	public MultChoiceAnswer selectAnswer(Scanner s){
		MultChoiceAnswer mca = new MultChoiceAnswer();		// instantiates a new Answer
		mca.linkQuestion(this);								// links to this Question
		mca.choose(s);										// selects and stores Answer
		return mca;
	}
	
	// prints all choices to screen, concatenated with letters
	public void listChoices(){
		char alphabet = 'A';
		for (int i=0; i<numChoices; i++){
			System.out.print(alphabet + ") " + choices.get(i) + "   ");
			alphabet++;	
		}
		System.out.println();
	}
	
	// adds a choice
	public void addChoice(String s){
		choices.add(s);
	}
	
	// deletes a choice
	public void deleteChoice(int i){
		choices.remove(i);
	}
	
	// sets number of choices
	public void setNumChoices(int i){
		numChoices = i;
	}
	
	// sets number of selectable choices
	public void setNumSelectableChoices(int i){
		numSelectableChoices = i;
	}
	
	// returns number of choices
	public int getNumChoices(){
		return numChoices;
	}
	
	// returns number of selectable choices
	public int getNumSelectableChoices(){
		return numSelectableChoices;
	}
}
