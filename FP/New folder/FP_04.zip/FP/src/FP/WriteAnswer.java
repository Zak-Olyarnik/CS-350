package FP;

import java.util.Scanner;

public class WriteAnswer extends Answer {
	
	private Write que;			// linked question
	private String ansField;	// text field for answer
	
	@Override
	public void choose(Scanner s){		// answer Write by typing text answer
		String ans;
		do{		// error checking - correct input length
			ans = s.nextLine().toUpperCase();
			if (getQuestion().getLength() == 30 && ans.length() > 30){
				System.out.println("Answer must not exceed 30 characters.  Enter answer:");
			}
		}while(getQuestion().getLength() == 30 && ans.length() > 30);
		setAns(ans);	// stores answer
	}
	
	@Override
	public void display(){
		if (getQuestion().getLength() == 30){
			System.out.println(ansField);
		}else{
			System.out.println("No answer available");	// for ungradeable essay questions
		}
	}
	
	@Override
	public void modify(Scanner s){						// this method is overridden because we only want to call choose() to change the answer if it's a 
		if (getQuestion().getLength() == 30){				// short answer, not an essay
			System.out.println("Enter correct answer:");
			choose(s);
		}
	}
	
	@Override
	public void linkQuestion(Question q){
		que = (Write) q;
	}
	
	@Override
	public Write getQuestion(){
		return que;
	}
	
	// stores Answer
	public void setAns(String s){
		ansField = s;
	}
}
