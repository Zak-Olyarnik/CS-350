package FP;

import java.util.Scanner;

public class WriteAnswer extends Answer {
	
	private Write que;			// linked question
	private String ansField;	// text field for answer
	
	public void choose(Scanner s){		// answer Write by typing text answer
		String ans = s.nextLine();
		// add error checking
		setAns(ans);
	}
	
	public void display(){				// overridden
		if (getQuestion().getLength() == 30){
			System.out.println(ansField);
		}else{
			System.out.println("No answer available");	// for ungradeable essay questions
		}
	}
	
	public void modify(Scanner s){		// overridden
		if (getQuestion().getLength() == 30){
			System.out.println("Enter correct answer:");
			choose(s);
		}
	}
	
	public void setAns(String s){
		ansField = s;
	}
	
	public void linkQuestion(Question q){
		que = (Write) q;
	}
	
	public Write getQuestion(){
		return que;
	}
}
