package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class MultChoice extends Question{

	private int numChoices;
	private int numSelectableChoices;
	private ArrayList<String> choices = new ArrayList<String>();	// list of choices
	
	public void create(Scanner s){					// creates multiple choice
		System.out.println("Enter a prompt for your multiple choice question:");
		setPrompt(s.nextLine());
		System.out.println("Enter the number of choices for your multiple choice question:");
		while (!s.hasNextInt()){
			System.out.println("Enter the number of choices for your multiple choice question:");
			s.next();
		}
		int nChoices = s.nextInt();
		s.nextLine();		// clears scanner
		setNumChoices(nChoices);
		
		for (int i=0; i<nChoices; i++){
			System.out.println("Enter answer choice #" + (i+1) + ":");
			addChoice(s.nextLine());
		}
		
		System.out.println("Enter the number of selectable choices for your multiple choice question:");
		int nSelChoices;		// must initialize for error checking
		do{
			while (!s.hasNextInt()){
			System.out.println("Enter the number of selectable choices for your multiple choice question:");
			s.next();
			}
			nSelChoices = s.nextInt();
			if(nSelChoices > nChoices){
				System.out.println("Selectable choices must not be greater than total choices.");
				System.out.println("Enter the number of selectable choices for your multiple choice question:");
			}
		} while (nSelChoices > nChoices);
		s.nextLine();		// clears scanner
		setNumSelectableChoices(nSelChoices);
	}
	
	public void display(){		// overridden
		System.out.println(getPrompt());
		char alphabet = 'A';
		for (int i=0; i<numChoices; i++){
			System.out.print(alphabet + ") " + choices.get(i) + "   ");		// concatenates the choices with letters
			alphabet++;	
		}
		System.out.println();
	}
	
	public void modify(Scanner s){
		display();
		System.out.println("Would you like to modify the prompt? (y/n)");
		if(s.nextLine().equals("y")){
			System.out.println("Enter a new prompt:");
			setPrompt(s.nextLine());
		}
		System.out.println("Would you like to modify the number of choices? (y/n)");
		if(s.nextLine().equals("y")){
			System.out.println("Enter the number of choices:");
			int newNumChoices = Integer.parseInt(s.nextLine());
			while (newNumChoices < getNumChoices()){		// deletes choices
				System.out.println("Enter letter of choice to delete:");
				char alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + choices.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				int pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				deleteChoice(pos);
				numChoices--;
			}
			while(newNumChoices > getNumChoices()){			// adds choices
				System.out.println("Enter new answer choice #" + (getNumChoices() + 1) + ":");
				addChoice(s.nextLine());
				numChoices++;
			}
		}
		System.out.println("Would you like to modify any of the choices? (y/n)");
		if(s.nextLine().equals("y")){
			do{
				System.out.println("Which choice would you like to modify?");
				char alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + choices.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				int pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				System.out.println("Enter new choice:");
				choices.set(pos, s.nextLine());
				System.out.println("Would you like to modify any of the choices? (y/n)");
			}while(s.nextLine().equals("y"));
		}
		System.out.println("Would you like to modify the number of selectable choices? (y/n)");
		if(s.nextLine().equals("y")){
			System.out.println("Enter the number of selectable choices:");
			setNumSelectableChoices(Integer.parseInt(s.nextLine()));
		}
	}
	
	public void addChoice(String s){
		choices.add(s);
	}
	
	public void deleteChoice(int i){
		choices.remove(i);
	}
	
	public void setNumChoices(int i){
		numChoices = i;
	}
	
	public void setNumSelectableChoices(int i){
		numSelectableChoices = i;
	}
	
	public int getNumChoices(){
		return numChoices;
	}
	
	public int getNumSelectableChoices(){
		return numSelectableChoices;
	}
}
