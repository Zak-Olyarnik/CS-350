package FP;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Questionnaire implements Serializable{

	private String title;			// identifying name
	//private String subject;
	private Boolean isGradeable;	// distinguishes between Survey and Test
	private ArrayList<Question> questionsList = new ArrayList<Question>();	// actual list of questions
	
	public void display(Scanner s){		// displays Questionnaire from file
		System.out.println(getTitle());
		//System.out.println(loaded.getSubject());
		System.out.println();
		for (int i=0; i<questionsList.size(); i++){
			System.out.print(i+1 + ") " );
			this.questionsList.get(i).display();
			System.out.println();
			}
	}
	
	public void save(){		// serializes to file.  All Surveys collected in a Survey folder with .Survey extension
		String folder;			// and Tests in Test folder with .Test extension
		if(getGradeable()){
			folder = "Test";
			
		}else{
			folder = "Survey";
		} 
		
		try
	      {
			new File(folder).mkdir();	// creates directory if does not exist
	        FileOutputStream outfile = new FileOutputStream(folder + "\\" + getTitle() + "." + folder);
	        ObjectOutputStream out = new ObjectOutputStream(outfile);
	        out.writeObject(this);
	        out.close();
	        outfile.close();
	        System.out.println(getTitle() + " saved successfully\n");
	      }catch(IOException i){
	          i.printStackTrace();
	      }
	}
	
	/*public void take(AnswerSheet a, Scanner s){		// take test, currently easiest way to add correct answers
		a.linkQuestionnaire(this);
		for (int i=0; i<this.questionsList.size(); i++){
			System.out.print(i+1 + ") " );
			this.questionsList.get(i).display();
			this.questionsList.get(i).selectAnswer(a, s);
			System.out.println();
		}
	}*/
	
	public void take(){
		
	}
	
	public int modify(Scanner s){
		System.out.println("Which question would you like to modify?");
		for (int i=0; i<questionsList.size(); i++){
			System.out.print(i+1 + ") " );
			this.questionsList.get(i).display();
			System.out.println();
		}
		int modQuest = Integer.parseInt(s.nextLine());
		return modQuest;
	}
	
	public void create(Scanner s, Boolean grad){	// creates Questionnaire
		String surveyOrTest;
		if(grad){
			surveyOrTest = "test";
		}else{
			surveyOrTest = "survey";
		}
		
		System.out.println("Enter a name for your " + surveyOrTest);
		setTitle(s.nextLine());
		//System.out.println("Enter the subject for your " + surveyOrTest);
		//setSubject(s.nextLine());
		setGradeable(grad);
	}
	
	public void delete(){
		
	}
	
	public void tabulate(){
		
	}
	
	public void addQuestion(Question q){
		questionsList.add(q);
	}
	
	public void setTitle(String s){
		title = s;
	}
	
	//public void setSubject(String s){
	//	subject = s;
	//}
	
	public void setGradeable(Boolean b){
		isGradeable = b;
	}
	
	public String getTitle(){
		return title;
	}
	
	//public String getSubject(){
	//	return subject;
	//}
	
	public Boolean getGradeable(){
		return isGradeable;
	}
	
	public Question getQuestion(int i){		// returns Question at position i
		return questionsList.get(i);
	}
}
