package FP;

import java.io.Serializable;
import java.util.Scanner;

public class Answer implements Serializable{	// parent class of all specific answers, serializable
	
	private Question que;

	public void choose(Scanner s){}		// overridden by all subclasses
	
	public void display(){}
	
	public void modify(Scanner s){ 
		System.out.println("Enter correct answer:");
		choose(s);		// subclass method
	}
	
	public void linkQuestion(Question q){	// overridden by all subclasses
		que = q;
	}
	
	public Question getQuestion(){		// overridden by all subclasses
		return que;
	}
}