package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class Matching extends Question{

	private int numChoices;
	private ArrayList<String> leftColumn = new ArrayList<String>();		// left column choices
	private ArrayList<String> rightColumn = new ArrayList<String>();	// right column choices
	
	public void create(Scanner s){
		System.out.println("Enter a prompt for your matching question:");
		setPrompt(s.nextLine());
		System.out.println("Enter the number of choices per column:");
		while (!s.hasNextInt()){
			System.out.println("Enter the number of choices per column:");
			s.next();
		}
		int nChoices = s.nextInt();
		s.nextLine();		// clears scanner
		setNumChoices(nChoices);
		for (int i=0; i<nChoices; i++){
			System.out.println("Enter left column choice #" + (i+1) + ":");
			addLeft(s.nextLine());
		}
		for (int i=0; i<nChoices; i++){
			System.out.println("Enter right column choice #" + (i+1) + ":");
			addRight(s.nextLine());		// concatenates the choices with letters
		}
	}
	
	public void display(){		// overridden from Question class
		System.out.println(getPrompt());	// method of Question class
		char alphabet = 'A';
		for (int i=0; i<numChoices; i++){
			System.out.println(leftColumn.get(i) + "				" + alphabet + ") " + rightColumn.get(i));		// concatenates the choices with letters
			alphabet++;	
		}
	}
	
	public void modify(Scanner s){
		display();
		System.out.println("Would you like to modify the prompt? (y/n)");
		if(s.nextLine().equals("y")){
			System.out.println("Enter a new prompt:");
			setPrompt(s.nextLine());
		}
		System.out.println("Would you like to modify the number of choices? (y/n)");
		if(s.nextLine().equals("y")){
			System.out.println("Enter the number of choices:");
			int newNumChoices = Integer.parseInt(s.nextLine());
			while (newNumChoices < getNumChoices()){		// deletes choices
				System.out.println("Enter letter of left column choice to delete:");
				char alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + leftColumn.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				int pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				leftDeleteChoice(pos);
				System.out.println("Enter letter of right column choice to delete:");
				alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + rightColumn.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				rightDeleteChoice(pos);
				numChoices--;
			}
			while(newNumChoices > getNumChoices()){			// adds choices
				System.out.println("Enter new left column choice #" + (getNumChoices() + 1) + ":");
				addLeft(s.nextLine());
				System.out.println("Enter new right column choice #" + (getNumChoices() + 1) + ":");
				addRight(s.nextLine());
				numChoices++;
			}
		}
		System.out.println("Would you like to modify any left column choices? (y/n)");
		if(s.nextLine().equals("y")){
			do{
				System.out.println("Which choice would you like to modify?");
				char alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + leftColumn.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				int pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				System.out.println("Enter new choice:");
				leftColumn.set(pos, s.nextLine());
				System.out.println("Would you like to modify any left column choices? (y/n)");
			}while(s.nextLine().equals("y"));
		}
		System.out.println("Would you like to modify any right column choices? (y/n)");
		if(s.nextLine().equals("y")){
			do{
				System.out.println("Which choice would you like to modify?");
				char alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + rightColumn.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				int pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				System.out.println("Enter new choice:");
				rightColumn.set(pos, s.nextLine());
				System.out.println("Would you like to modify any of the choices? (y/n)");
			}while(s.nextLine().equals("y"));
		}
	}
	
	public void addLeft(String s){
		leftColumn.add(s);
	}
	
	public void addRight(String s){
		rightColumn.add(s);
	}
	
	public void leftDeleteChoice(int i){
		leftColumn.remove(i);
	}
	
	public void rightDeleteChoice(int i){
		rightColumn.remove(i);
	}
	
	public void setNumChoices(int i){
		numChoices = i;
	}
	
	public int getNumChoices(){
		return numChoices;
	}
	
	public String getLeft(int i){
		return leftColumn.get(i);
	}
}

