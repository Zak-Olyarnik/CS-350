package FP;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class AnswerSheet implements Serializable{

	private ArrayList<Answer> answersList = new ArrayList<Answer>();		// actual list of all answers
	private Questionnaire quest;		// linked Questionnaire
	
	public void display(){		// loads AnswerSheet from file and displays to console
		System.out.println("Answers:");
		for(int i=0; i<answersList.size(); i++){
			System.out.print(i+1 + ") " );
			answersList.get(i).display();
			System.out.println();
		}
	}

	public void save(){		// serializes to file.  All AnswerSheets saved in Answer folder with .Answer extension
		try
	      {
			new File("Answer").mkdir();		// creates Answer directory if does not exist
	        FileOutputStream outfile = new FileOutputStream("Answer\\" + getQuestionnaire().getTitle() + ".Answer");
	        ObjectOutputStream out = new ObjectOutputStream(outfile);
	        out.writeObject(this);
	        out.close();
	        outfile.close();
	        System.out.println(getQuestionnaire().getTitle() + " answers saved successfully");
	      }catch(IOException i){
	          i.printStackTrace();
	      }
	}
	
	public void addAnswer(Answer a){
		answersList.add(a);
	}
	
	public void linkQuestionnaire(Questionnaire q){
		quest = q;
	}
	
	public Questionnaire getQuestionnaire(){
		return quest;
	}
	
	public Answer getAnswer(int i){		// gets the Answer at position i
		return answersList.get(i);
	}
	
	public int getSize(){				// gets the number of Answers
		return answersList.size();
	}
	
}
