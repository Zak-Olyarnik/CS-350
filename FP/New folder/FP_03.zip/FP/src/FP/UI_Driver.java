package FP;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class UI_Driver {
	
	private static ArrayList<Questionnaire> localSurveys = new ArrayList<Questionnaire>();	// container for all Surveys
	private static ArrayList<Questionnaire> localTests = new ArrayList<Questionnaire>();	// container for all Tests

	public static void main(String[] args) {
		UI_Driver driver = new UI_Driver();
		driver.mainMenu();			// loads main menu
	}

	public void mainMenu(){
		String menu = "1  - Create a new Survey\n"
				 	+ "2  - Create a new Test\n"
				 	+ "3  - Display a Survey\n"
				 	+ "4  - Display a Test\n"
				 	+ "5  - Save a Survey\n"
				 	+ "6  - Save a Test\n"
				 	+ "7  - Modify an existing Survey\n"
				 	+ "8  - Modify an existing Test\n"
				 	+ "9  - Exit\n";
				 	//+ "9  - Load a Survey - COMING SOON\n";
				 	//+ "10 - Load a Test - COMING SOON\n"
				 	//+ "11 - Take a Survey - COMING SOON\n"
				 	//+ "12 - Take a Test - COMING SOON\n"
				 	//+ "13 - Grade a Test - COMING SOON\n"
				 	//+ "14 - Tabulate a Survey - COMING SOON\n"
				 	//+ "15 - Tabulate a Test - COMING SOON\n"

		System.out.println(menu);
		
		Scanner s = new Scanner(System.in);
		String choice = s.nextLine();		// reads in choice
		
		while (! choice.equals("9")){		// loops to take in new commands
			switch (choice){
			case "1":	// create Survey
				Questionnaire q = new Questionnaire();
				q.create(s, false);			// differentiates as Survey
				addMenu(s, q);				// adds Questions
				localSurveys.add(q);		// adds to list of Surveys
				q.save();					// auto-saves
				break;
			case "2":	// create Test
				q = new Questionnaire();
				q.create(s, true);
				addMenu(s, q);
				localTests.add(q);
				q.save();
				break;
			case "3":	// display Survey
				q = loadQuestionnaire(s, false, "display");
				if (q != null){
					q.display(s);
				}
				break;
			case "4":	// display Test
				q = loadQuestionnaire(s, true, "display");
				if (q != null){
					q.display(s);
					AnswerSheet a = loadAnswerSheet(q);
					//a.linkQuestionnaire(q);
					a.display();
				}
				break;
			case "5":	// save Survey from the local list of recently modified
				if (localSurveys.size() == 0){
					System.out.println("No modified Surveys to save\n");
				}else{
					System.out.println("Which Survey would you like to save?");
					int i = 1;
					for(Questionnaire survey : localSurveys){
						System.out.println(i + " - " + survey.getTitle());
						i++;
					}
					//add error checking on input
					Questionnaire toSave = localSurveys.get(Integer.parseInt(s.nextLine()) - 1);
					toSave.save();
				}
				break;
			case "6":	// save Test from the local list of recently modified
				if (localTests.size() == 0){
					System.out.println("No modified Tests to save\n");
				}else{
					System.out.println("Which Test would you like to save?");
					int i = 1;
					for(Questionnaire test : localTests){
						System.out.println(i + " - " + test.getTitle());
						i++;
					}
					//add error checking on input
					Questionnaire toSave = localTests.get(Integer.parseInt(s.nextLine()) - 1);
					toSave.save();
				}
				break;
			case "7":	// modify survey
				q = loadQuestionnaire(s, false, "modify");
				if (q != null){
					do{
						int modQuest = q.modify(s) - 1;
						q.getQuestion(modQuest).modify(s);
						q.getQuestion(modQuest).display();
						System.out.println("Modify another question? (y/n)");
					} while(s.nextLine().equals("y"));
					localSurveys.add(q);
					q.save();
				}
				break;
			case "8":	// modify test
				q = loadQuestionnaire(s, true, "modify");
				if (q != null){
					AnswerSheet a = loadAnswerSheet(q);
					do{
						int modQuest = q.modify(s) - 1;
						q.getQuestion(modQuest).modify(s);
						q.getQuestion(modQuest).display();
						a.getAnswer(modQuest).linkQuestion(q.getQuestion(modQuest));
						a.getAnswer(modQuest).modify(s);
						q.getQuestion(modQuest).display();
						a.getAnswer(modQuest).display();
						System.out.println("Modify another question? (y/n)");
					} while(s.nextLine().equals("y"));
					localTests.add(q);
					a.save();
					q.save();
				}
				break;
			/*case "9":	// load survey
				break;
			case "10":	// load test
				break;
			case "11":	// take survey
				break;
			case "12":	// take test
				break;
			case "13":	// grade test
				break;
			case "14":	// tabulate survey
				break;
			case "15":	// tabulate test
				break;*/
			default:	// bad input
				System.out.println("Please enter the number of your choice.\n");
				break;
			}
			System.out.println(menu);	// resets menu
			choice = s.nextLine();
		}
		s.close();
		System.exit(0);
	}
	
	public void addMenu(Scanner s, Questionnaire q){			// adds Questions.  If more question types are added, changes should be localized here
		String addMenu = "\n1 - Add a new True or False Question\n"
						 + "2 - Add a new Multiple Choice Question\n"
						 + "3 - Add a new Short Answer Question\n"
						 + "4 - Add a new Essay Question\n"
						 + "5 - Add a new Matching Question\n"
						 + "6 - Add a new Ranking Question\n"
						 + "7 - Finish and Save\n";
		AnswerSheet key = new AnswerSheet();		// AnswerSheets for Tests are created at the same time as Test
		
		if(q.getGradeable()){
			key.linkQuestionnaire(q);
		}
		
		System.out.println(addMenu);
		String choice = s.nextLine();
		
		while (! choice.equals("7")){	// loop to take in new commands
			switch (choice){
			case "1":	// true or false
				TrueFalse tf = new TrueFalse();
				tf.create(s);
				tf.display();
				if (q.getGradeable()){			// Test Answers instantiated at the same time as Questions
					TrueFalseAnswer tfa = new TrueFalseAnswer();
					System.out.println("Enter correct answer:");
					tfa.linkQuestion(tf);
					tfa.choose(s);
					key.addAnswer(tfa);
				}
				q.addQuestion(tf);
				break;
			case "2":	// multiple choice
				MultChoice mc = new MultChoice();
				mc.create(s);
				mc.display();
				if (q.getGradeable()){
					MultChoiceAnswer mca = new MultChoiceAnswer();
					System.out.println("Enter correct answer:");
					mca.linkQuestion(mc);
					mca.choose(s);
					key.addAnswer(mca);
				}
				q.addQuestion(mc);
				break;
			case "3":	// short answer
				Write sa = new Write();
				sa.create(s, 30);		// short answer has max length of 30
				sa.display();
				if (q.getGradeable()){
					WriteAnswer wa = new WriteAnswer();
					System.out.println("Enter correct answer:");
					wa.linkQuestion(sa);
					wa.choose(s);
					key.addAnswer(wa);
				}
				q.addQuestion(sa);
				break;
			case "4":	// essay
				Write es = new Write();
				es.create(s, 1500);		// essay has max length of 1500
				es.display();
				if (q.getGradeable()){
					WriteAnswer wa = new WriteAnswer();
					//System.out.println("Enter correct answer:");		// essay questions do not have default correct answers and can't be graded
					wa.linkQuestion(es);
					//wa.choose(s);
					key.addAnswer(wa);
				}
				q.addQuestion(es);
				break;
			case "5":	// matching
				Matching ma = new Matching();
				ma.create(s);
				ma.display();
				if (q.getGradeable()){
					MatchingAnswer maa = new MatchingAnswer();
					System.out.println("Enter correct answer:");
					maa.linkQuestion(ma);
					maa.choose(s);
					key.addAnswer(maa);
				}
				q.addQuestion(ma);
				break;
			case "6":	// ranking
				Ranking ra = new Ranking();
				ra.create(s);
				ra.display();
				if (q.getGradeable()){
					RankingAnswer raa = new RankingAnswer();
					System.out.println("Enter correct answer:");
					raa.linkQuestion(ra);
					raa.choose(s);
					key.addAnswer(raa);
				}
				q.addQuestion(ra);
				break;
			default:	// bad input
				System.out.println("Please enter the number of your choice.");
				break;
			}
			System.out.println(addMenu);	// resets menu
			choice = s.nextLine();
		}
		if (q.getGradeable()){
			key.save();
		}
	}
	
	public Questionnaire loadQuestionnaire(Scanner s, Boolean isGradeable, String action){		// deserializes from file
		String folder;							// load operations were moved to the Driver to avoid the issue of instantiating a Questionnaire
		Questionnaire loaded = null;				// simply to call the load method which instantiated and then loaded a new one
		if(isGradeable){
			folder = "Test";	
		}else{
			folder = "Survey";
		}
		
		File directory = new File(folder);
		if (!directory.exists() || directory.listFiles().length == 0){	// folder does not exist or is empty
			System.out.println("No " + folder + "s found\n");
		}else{
			System.out.println("Which " + folder + " would you like to " + action + "?");
			int i = 1;
			for (File file : directory.listFiles()) {
				System.out.println(i + " - " + file.getName());
				i++;
			}
		
			// error checking
			String filename = s.nextLine();
			filename = folder + "\\" + directory.listFiles()[Integer.parseInt(filename) - 1].getName();
			
			try
			{
				FileInputStream infile = new FileInputStream(filename);
				ObjectInputStream in = new ObjectInputStream(infile);
				loaded = (Questionnaire) in.readObject();
				in.close();
				infile.close();
			}catch(IOException e){
				e.printStackTrace();
				return loaded;
			}catch(ClassNotFoundException c){
				System.out.println("Class not found");
				c.printStackTrace();
				return loaded;
			}
			return loaded;
		}
		return loaded;
		}
	
	public AnswerSheet loadAnswerSheet(Questionnaire q){		// deserializes AnswerSheet from file
		AnswerSheet loaded = null;
		String filename = "Answer\\" + q.getTitle() + ".Answer";	// AnswerSheet named based on Test
			
		try
		{
			FileInputStream infile = new FileInputStream(filename);
			ObjectInputStream in = new ObjectInputStream(infile);
			loaded = (AnswerSheet) in.readObject();
			in.close();
			infile.close();
		}catch(IOException e){
			e.printStackTrace();
			return loaded;
		}catch(ClassNotFoundException c){
			System.out.println("Class not found");
			c.printStackTrace();
			return loaded;
		}
		loaded.linkQuestionnaire(q);
		//for (int i=0; i<loaded.getSize(); i++){
		//	loaded.getAnswer(i).display();
		//}
		return loaded;
	}
}
