package FP;

import java.util.Scanner;

public class TrueFalseAnswer extends Answer {

	private TrueFalse que;		// linked question
	private char ans;			// answer letter
	
	public void choose(Scanner s){		// answer MultChoice by entering letter of correct answer (possibly multiple)
		String choice = s.nextLine();
		// add error checking
		setAns(choice.charAt(0));
	}
	
	public void display(){
		System.out.println(ans);
	}
	
	public void setAns(char c){
		ans = c;
	}
	
	public void linkQuestion(Question q){
		que = (TrueFalse) q;
	}
	
	public TrueFalse getQuestion(){
		return que;
	}
}

