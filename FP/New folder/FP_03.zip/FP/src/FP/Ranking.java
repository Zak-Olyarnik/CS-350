package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class Ranking extends Question{

	private int numChoices;
	private ArrayList<String> choices = new ArrayList<String>();		// list of choices
	
	public void create(Scanner s){
		System.out.println("Enter a prompt for your ranking question:");
		setPrompt(s.nextLine());
		System.out.println("Enter the number of choices to rank:");
		while (!s.hasNextInt()){
			System.out.println("Enter the number of choices to rank:");
			s.next();
		}
		int nChoices = s.nextInt();
		s.nextLine();		// clears scanner
		setNumChoices(nChoices);
		for (int i=0; i<nChoices; i++){
			System.out.println("Enter answer choice #" + (i+1) + ":");
			addChoice(s.nextLine());
		}
	}
	
	public void display(){		// overridden
		System.out.println(getPrompt());
		char alphabet = 'A';
		for (int i=0; i<numChoices; i++){
			System.out.print(alphabet + ") " + choices.get(i) + "   ");		// concatenates the choices with letters
			alphabet++;	
		}
		System.out.println();
	}
	
	public void modify(Scanner s){		// overridden
		display();
		System.out.println("Would you like to modify the prompt? (y/n)");
		if(s.nextLine().equals("y")){
			System.out.println("Enter a new prompt:");
			setPrompt(s.nextLine());
		}
		System.out.println("Would you like to modify the number of choices? (y/n)");
		if(s.nextLine().equals("y")){
			System.out.println("Enter the number of choices:");
			int newNumChoices = Integer.parseInt(s.nextLine());
			while (newNumChoices < getNumChoices()){		// deletes choices
				System.out.println("Enter letter of choice to delete:");
				char alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + choices.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				int pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				deleteChoice(pos);
				setNumChoices(getNumChoices() - 1);
			}
			while(newNumChoices > getNumChoices()){			// adds choices
				System.out.println("Enter new answer choice #" + (getNumChoices() + 1) + ":");
				addChoice(s.nextLine());
				setNumChoices(getNumChoices() + 1);
			}
		}
		System.out.println("Would you like to modify any of the choices? (y/n)");
		if(s.nextLine().equals("y")){
			do{
				System.out.println("Which choice would you like to modify?");
				char alphabet = 'A';
				for (int i=0; i<numChoices; i++){
					System.out.print(alphabet + ") " + choices.get(i) + "   ");		// concatenates the choices with letters
					alphabet++;
				}
				System.out.println();
				int pos = Character.getNumericValue(s.nextLine().charAt(0)) - 10;
				System.out.println("Enter new choice:");
				choices.set(pos, s.nextLine());
				System.out.println("Would you like to modify any of the choices? (y/n)");
			}while(s.nextLine().equals("y"));
		}
	}
	
	public void addChoice(String s){
		choices.add(s);
	}
	
	public void deleteChoice(int i){
		choices.remove(i);
	}
	
	public void setNumChoices(int i){
		numChoices = i;
	}
	
	public int getNumChoices(){
		return numChoices;
	}
}
