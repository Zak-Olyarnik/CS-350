package FP;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class AnswerSheet implements Serializable{

	private ArrayList<Answer> answersList = new ArrayList<Answer>();		// actual list of all answers
	private Questionnaire quest;		// linked Questionnaire
	
	public void display(){		// loads AnswerSheet from file and displays to console
		AnswerSheet loaded = load();
		System.out.println("Answers:");
		for(int i=0; i<loaded.answersList.size(); i++){
			System.out.print(i+1 + ") " );
			loaded.answersList.get(i).display();
			System.out.println();
		}
	}
	
	public AnswerSheet load(){		// deserializes AnswerSheet from file
		AnswerSheet loaded = null;
		String filename = "Answer\\" + getQuestionnaire().getTitle() + ".Answer";	// AnswerSheet named based on Test
			
		try
		{
			FileInputStream infile = new FileInputStream(filename);
			ObjectInputStream in = new ObjectInputStream(infile);
			loaded = (AnswerSheet) in.readObject();
			in.close();
			infile.close();
		}catch(IOException e){
			e.printStackTrace();
			return loaded;
		}catch(ClassNotFoundException c){
			System.out.println("Class not found");
			c.printStackTrace();
			return loaded;
		}
		return loaded;
	}

	public void save(){		// serializes to file.  All AnswerSheets saved in Answer folder with .Answer extension
		try
	      {
			new File("Answer").mkdir();		// creates Answer directory if does not exist
	        FileOutputStream outfile = new FileOutputStream("Answer\\" + getQuestionnaire().getTitle() + ".Answer");
	        ObjectOutputStream out = new ObjectOutputStream(outfile);
	        out.writeObject(this);
	        out.close();
	        outfile.close();
	        System.out.println(getQuestionnaire().getTitle() + " answers saved successfully\n");
	      }catch(IOException i){
	          i.printStackTrace();
	      }
	}
	
	public void addAnswer(Answer a){
		answersList.add(a);
	}
	
	public void linkQuestionnaire(Questionnaire q){
		quest = q;
	}
	
	public Questionnaire getQuestionnaire(){
		return quest;
	}
	
}
