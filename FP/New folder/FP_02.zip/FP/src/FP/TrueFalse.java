package FP;

import java.util.ArrayList;
import java.util.Scanner;

public class TrueFalse extends Question{
	private ArrayList<String> choices = new ArrayList<String>();	// list of choices
	
	public void create(Scanner s){		// creates true or false
		System.out.println("Enter a prompt for your true or false question:");
		setPrompt(s.nextLine());
		addChoice("A) True");
		addChoice("B) False");
	}
	
	public void display(){		// overridden from Question class
		System.out.println(getPrompt());	// method of Question class
		for (int i=0; i<2; i++){			// true or false will always only have 2 choices
			System.out.print(choices.get(i) + "   ");
		}
		System.out.println();
	}
	
	public void addChoice(String s){
		choices.add(s);
	}
}
