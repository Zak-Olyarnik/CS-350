package maze;

public interface Command {
	public void execute();
}
