package maze;

import java.awt.Color;

public class RedWall extends Wall{

	@Override
	public Color getColor()
	{
		return Color.RED;
	}
}
