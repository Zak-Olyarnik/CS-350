package Lab1;

public class AlarmClockRadio extends AlarmClock{

	private Radio radio = new Radio();
	
	public Radio getRadio(){
		return radio;
	}
}
